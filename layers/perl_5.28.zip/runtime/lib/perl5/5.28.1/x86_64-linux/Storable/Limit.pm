# bisected by stacksize
$Storable::recursion_limit = 13646
  unless defined $Storable::recursion_limit;
$Storable::recursion_limit_hash = 8181
  unless defined $Storable::recursion_limit_hash;
1;
